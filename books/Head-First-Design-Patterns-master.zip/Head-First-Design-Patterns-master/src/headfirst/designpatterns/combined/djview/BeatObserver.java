package headfirst.designpatterns.combined.djview;
  
public interface BeatObserver {
	void updateBeat();
}
