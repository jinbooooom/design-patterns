package headfirst.designpatterns.factory.challenge;

public class ZoneMountain extends Zone {
	public ZoneMountain() {
		displayName = "US/Mountain";
		offset = -7;
	}
}