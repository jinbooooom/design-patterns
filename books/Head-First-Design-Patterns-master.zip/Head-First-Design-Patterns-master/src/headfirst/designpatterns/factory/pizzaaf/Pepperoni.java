package headfirst.designpatterns.factory.pizzaaf;

public interface Pepperoni {
	public String toString();
}
